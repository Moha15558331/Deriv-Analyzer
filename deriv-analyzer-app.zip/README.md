# Deriv Analyzer — Installable App

This is your Deriv Analyzer turned into a **Progressive Web App (PWA)**.  
Once hosted, you can install it on your phone and it opens like a native app (full screen, home screen icon, no browser bar).

## How to install on your phone

### 1. Host it (free, 1 minute)
The easiest way:
1. Go to [https://app.netlify.com/drop](https://app.netlify.com/drop)
2. Drag this entire folder (or the zip) onto the page
3. You get a live URL instantly (e.g. `https://something.netlify.app`)

Other free options: Vercel, Cloudflare Pages, GitHub Pages, or any static host.

### 2. Install on Android
1. Open the URL in **Chrome**
2. Tap the menu (⋮) → **Add to Home screen** or **Install app**
3. Done — it appears as a real app icon

### 3. Install on iPhone
1. Open the URL in **Safari**
2. Tap the Share button → **Add to Home Screen**
3. Name it and tap Add

The app runs full-screen with your custom icon.  
Your Deriv token stays only on your device (localStorage).

## Files
- `index.html` — the full app
- `manifest.json` — PWA config
- `sw.js` — offline support for the UI
- `icons/` — app icons

## Notes
- Live market data and trading still need internet + your Deriv token
- The service worker caches the app shell so it loads instantly
